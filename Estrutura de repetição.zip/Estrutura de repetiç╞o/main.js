let quantidade_de_numeros= prompt('informe a quantidade de números a serem utilizados')
let soma= 0
for ( var i=0; i < Number(quantidade_de_numeros);i++) {
    var numero_informado= prompt('informe um número')
    soma= soma + Number(numero_informado)


}
alert('a soma é '+soma)
alert('A média é ' + soma / numero_informado)


